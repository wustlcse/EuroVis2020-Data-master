An attempt to create a graph flow lib using d3 😈
:hammer: work in progress

![Screenshot](https://github.com/LironHazan/directed-graph-flow-experiments/blob/master/graph.png)
